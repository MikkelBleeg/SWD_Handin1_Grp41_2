﻿using System.Windows;

namespace WpfDemoApp
{
    public partial class DemoWindow : Window
    {
        public DemoWindow()
        {
            InitializeComponent();
        }
    }
}
﻿using System.Windows.Controls;

namespace WpfDemoApp.Views
{
    public partial class NumberView : UserControl
    {
        public NumberView()
        {
            InitializeComponent();
        }
    }
}
**Project Description**
MVVM Foundation is a library of classes that are very useful when building applications based on the Model-View-ViewModel philosophy.  The library is small and concentrated on providing only the most indispensable tools needed by most MVVM application developers.

To download the latest version of MVVM Foundation, go to the **Source Code** tab on this page.

[Model-View-ViewModel](http://msdn.microsoft.com/en-us/magazine/dd419663.aspx) is a way of creating client applications that leverages core features of the WPF platform, allows for simple unit testing of application functionality, and helps developers and designers work together with less technical difficulties.  The classes in the MVVM Foundation are time-tested tools in the toolbox of many WPF developers around the world.  Now they all live in one convenient project...MvvmFoundation.Wpf.  The source code download also contains a set of unit tests and a demo application, which show how to use the classes.  If you want to learn more about MVVM be sure to read Josh Smith's [Advanced MVVM](http://advancedmvvm.com) book.

[ObservableObject](http://msdn.microsoft.com/en-us/magazine/dd419663.aspx#id0090051) - This is intended to be the base class for ViewModel types, or any type that must provide property change notifications.  It implements INotifyPropertyChanged and, in debug builds, will verify that all property names passed through the PropertyChanged event are valid properties.  This class used to be called ViewModelBase.

[RelayCommand](http://msdn.microsoft.com/en-us/magazine/dd419663.aspx#id0090030) - Provides for small, simple command declarations.  The execution logic, and optionally can-execute logic, is injected into its constructor.

[PropertyObserver](http://joshsmithonwpf.wordpress.com/2009/07/11/one-way-to-avoid-messy-propertychanged-event-handling/) - A standardized way to handle the INotifyPropertyChanged.PropertyChanged event of other objects.  This class uses weak references and the weak-event pattern to prevent memory leaks.

[Messenger](http://marlongrech.wordpress.com/2009/04/16/mediator-v2-for-mvvm-wpf-and-silverlight-applications/) - The Messenger class is a lightweight way of passing messages between various ViewModel objects who do not need to be aware of each other.  This is based on the Mediator implementation created by Marlon Grech and Josh Smith, as seen on Marlon's blog.

MVVM Foundation is currently geared toward WPF only, but a Silverlight-compatible version will be added as time permits.  